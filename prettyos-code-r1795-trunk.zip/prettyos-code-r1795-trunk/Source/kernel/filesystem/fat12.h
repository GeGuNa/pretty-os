#ifndef FAT12_H
#define FAT12_H

#include "os.h"


int32_t flpydsk_read_directory(const char* path);


#endif
