#ifndef FLOAT_H
#define FLOAT_H

#define FLT_RADIX 2

#endif
