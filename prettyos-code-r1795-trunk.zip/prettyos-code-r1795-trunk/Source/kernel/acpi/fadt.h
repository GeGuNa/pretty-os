#ifndef FADT_H
#define FADT_H

#include "acpi.h"


void acpi_parser_fadt(acpi_header_t* table);


extern const char* const fadtPath;


#endif
