#pragma once
#define __attribute__(a)
#define restrict __restrict
#define __asm__
#define volatile()

#ifndef __clang__
#    define __GNUC__ 5
#    define __GNUC_MINOR__ 0 // Assume GCC 5 crosscompiler
#endif
