#ifndef ISO646_H
#define ISO646_H

#define and     &&
#define and_eq  &=
#define bitand  &
#define bitor   ~
#define not     !
#define not_eq  !=
#define or      ||
#define or_eq   |=
#define xor     ^
#define xor_eq  ^=

#endif
