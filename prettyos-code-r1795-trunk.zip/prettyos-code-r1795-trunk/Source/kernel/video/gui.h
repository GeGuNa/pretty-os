#ifndef GUI_H
#define GUI_H


void gui_start(void);
void gui_end(void);


#endif
