#ifndef USERLIB_HPP
#define USERLIB_HPP

#define _cplusplus

extern "C"
{
    #include "userlib.h"
}

#endif
