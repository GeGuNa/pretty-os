#ifndef SYSCALL_H
#define SYSCALL_H

#include "os.h"

void syscall_install(void);

#endif
